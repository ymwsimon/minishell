/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   build_ast.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mayeung <mayeung@student.42london.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/11 20:46:40 by mayeung           #+#    #+#             */
/*   Updated: 2024/02/14 12:43:07 by mayeung          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

char	*ft_enum_to_str(t_token_type t)
{
	char	*res;

	res = NULL;
	if (t == PIPE)
		res = ft_strdup("|");
	else if (t == HERE_DOC)
		res = ft_strdup("<<");
	else if (t == INPUT)
		res = ft_strdup("<");
	else if (t == OUTPUT)
		res = ft_strdup(">");
	else if (t == APPEND)
		res = ft_strdup(">>");
	else if (t == AND)
		res = ft_strdup("&&");
	else if (t == OR)
		res = ft_strdup("||");
	return (res);
}
void	ft_free_ast(t_ast *node)
{
	if (!node)
		return ;
	/*if (node->tok->toktype == SIMPLE_CMD)
	{
		ft_clear_char_arr(node->tok->cmd->args);
		ft_clear_char_arr(node->tok->cmd->redirs);
		free(node->tok->cmd);
	}
	else if (ft_is_pipe_tok(node->tok) || ft_is_and_tok(node->tok)
			|| ft_is_or_tok(node->tok))
		free(node->tok->str);
	free(node->tok);
	ft_free_ast(node->left);
	ft_free_ast(node->right);*/
}

void	ft_print_ast(t_ast *node)
{
	size_t	i;
	char	*tmp;
	t_token	t;

	if (!node)
		return ;
	//ft_print_enum(node->toktype);
	//printf("%s\n", node->cmd->args[0]);
	t.toktype = node->toktype;
	if (ft_is_pipe_tok(&t) || ft_is_and_tok(&t)
		|| ft_is_or_tok(&t))
	{
		ft_print_ast(node->left);
		tmp = ft_enum_to_str(node->toktype);
		printf(" %s ", tmp);
		ft_print_ast(node->right);
		free(tmp);
	}
	else if (node->toktype == SIMPLE_CMD)
	{
		ft_print_enum(node->toktype);
		i = 0;
		while (node->cmd->args[i])
			printf("%s ", node->cmd->args[i++]);
		i = 0;
		while (node->cmd->redirs[i])
			printf("%s ", node->cmd->redirs[i++]);
	}
	else if (node->toktype == SUBSHELL)
	{
		printf("(");
		ft_print_ast(node->left);
		printf(")");
	}
}

int	ft_check_sym(t_list *n, int symbol_to_check)
{
	t_token	*t;

	t = n->content;
	if (symbol_to_check == OPENPAR_AND_OR_PIPE)
		return (ft_is_open_paren_tok(t) || ft_is_and_tok(t)
			|| ft_is_or_tok(t) || ft_is_pipe_tok(t));
	else
		return (ft_is_open_paren_tok(t) || ft_is_close_paren_tok(t));
}

t_ast	*ft_break_into_ast_node(t_list *lhead, t_list *parent, t_list *rhead)
{
	t_ast	*res;
	t_list	*node;

	res = malloc(sizeof(t_ast));
	if (!res)
		return (NULL);
	res->toktype = ((t_token *)parent->content)->toktype;
	node = lhead;
	while (node->next != parent)
		node = node->next;
	node->next = NULL;
	res->left = ft_build_ast(lhead);
	res->right = ft_build_ast(rhead);
	//ft_lstdelone(parent, &ft_free_token_node);
	return (res);
}

t_ast	*ft_break_into_subshell(t_list *tokens)
{
	t_ast	*res;
	t_list	*last;
	t_list	*node;

	res = malloc(sizeof(t_ast));
	if (!res)
		return (NULL);
	res->right = NULL;
	res->toktype = SUBSHELL;
	last = ft_lstlast(tokens);
	node = tokens;
	while (node->next != last)
		node = node->next;
	node->next = NULL;
	//ft_lstdelone(last, &ft_free_token_node);
	node = tokens->next;
	//ft_lstdelone(tokens, &ft_free_token_node);
	res->left = ft_build_ast(node);
	return (res);
}

t_ast	*ft_break_into_sc(t_list *tokens)
{
	t_ast	*res;
	t_list	*node;
	size_t	nredirs;
	size_t	narg;

	res = malloc(sizeof(t_ast));
	if (!res)
		return (NULL);
	res->left = NULL;
	res->right = NULL;
	res->toktype = SIMPLE_CMD;
	narg = 0;
	nredirs = 0;
	node = tokens;
	while (node)
	{
		if (ft_is_arg_tok(node->content))
			narg++;
		else if (ft_is_redir_tok(node->content))
			nredirs++;
		node = node->next;
	}
	res->cmd = malloc(sizeof(t_cmd));
	if (!res->cmd)
		return (free(res), NULL);
	res->cmd->args = malloc(sizeof(char *) * (narg + 1));
	//if  !res->cmd->args clean up and exit
	res->cmd->redirs = malloc(sizeof(char *) * (nredirs * 2 + 1));
	//if !res->cmd_redirs clean up and exti
	node = tokens;
	narg = 0;
	nredirs = 0;
	while (node)
	{
		if (ft_is_arg_tok(node->content))
			res->cmd->args[narg++] = ((t_token *)node->content)->str;
		else if (ft_is_redir_tok(node->content)
			|| ft_is_infile_tok(node->content)
			|| ft_is_outfile_tok(node->content)
			|| ft_is_delimiter_tok(node->content))
			res->cmd->redirs[nredirs++] = ((t_token *)node->content)->str;
		node = node->next;
	}
	res->cmd->args[narg] = NULL;
	res->cmd->redirs[nredirs] = NULL;
	return (res);
}

t_ast	*ft_build_ast(t_list *tokens)
{
	t_list		*iter;
	int			symbol_to_check;
	int			n_open_par;

	if (!tokens)
		return (NULL);
	iter = tokens;
	symbol_to_check = OPENPAR_AND_OR_PIPE;
	n_open_par = 0;
	while (iter)
	{
		if (ft_check_sym(iter, symbol_to_check)
			&& ft_is_open_paren_tok(iter->content))
		{
			symbol_to_check = PAREN;
			n_open_par++;
		}
		else if (ft_check_sym(iter, symbol_to_check)
			&& ft_is_close_paren_tok(iter->content))
		{
			n_open_par--;
			if (!n_open_par)
				symbol_to_check = OPENPAR_AND_OR_PIPE;
		}
		else if (ft_check_sym(iter, symbol_to_check))
			return (ft_break_into_ast_node(tokens, iter, iter->next));
		iter = iter->next;
	}
	if (ft_is_open_paren_tok(tokens->content))
		return (ft_break_into_subshell(tokens));
	else
		return (ft_break_into_sc(tokens));
}
